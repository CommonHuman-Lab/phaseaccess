"""
PhaseAccess — engine/__init__.py
Public API for the PhaseAccess engine.

Import surface:
    from engine import scan, ScanOptions
    from engine.reporter import ScanResult, IDORFinding, Confidence
    from engine.session import Session, SessionPair, pair_from_config
"""

from .scanner import scan, ScanOptions
from .reporter import ScanResult, IDORFinding, IDORType, Confidence, IDORLocation, IDType

__all__ = [
  "scan",
  "ScanOptions",
  "ScanResult",
  "IDORFinding",
  "IDORType",
  "Confidence",
  "IDORLocation",
  "IDType",
]
